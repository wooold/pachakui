// src/types/styles.d.ts

declare module '@styles/*';
