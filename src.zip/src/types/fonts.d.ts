// src/types/fonts.d.ts

declare module '@fontsource/inter';
declare module '@fontsource/inter/variable.css';
