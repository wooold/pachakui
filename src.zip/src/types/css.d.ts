// src/types/css.d.ts

declare module '*.css';
