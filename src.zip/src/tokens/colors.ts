import { primitives } from '@tokens/colors-primitives';

export const colors = {
  brand: {
    primary: primitives.blue500,
  },

  neutral: {
    white: primitives.white,
    soft: primitives.gray50,
    background: primitives.gray100,
    border: primitives.gray200,
    muted: primitives.gray400,
  },

  text: {
    primary: primitives.black,
    muted: primitives.gray400,
  },

  feedback: {
    error: primitives.red500,
    success: primitives.green500,
  },

  control: {
    on: primitives.blue500,        // mismo que brand.primary
    off: primitives.gray300,       // mejor contraste para apagado
    knob: primitives.white,
    disabled: primitives.gray100,
  },

  transparent: primitives.transparent,
};
